create
  definer = root@localhost procedure getEmployeeENameByID(IN employeeID int, OUT employeeENAME varchar(30))
BEGIN
	 SELECT employeeENAME
	 FROM employee
	 WHERE ID = employeeID;
 END;

