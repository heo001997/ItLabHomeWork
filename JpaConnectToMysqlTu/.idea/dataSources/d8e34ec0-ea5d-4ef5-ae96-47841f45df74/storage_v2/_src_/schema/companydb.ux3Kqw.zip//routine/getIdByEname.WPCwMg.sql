create
  definer = root@localhost procedure getIdByEname(IN TEMPNAME varchar(30), OUT EID int)
BEGIN
	SELECT ID
    FROM EMPLOYEE
    WHERE ENAME = TEMPNAME;
END;

