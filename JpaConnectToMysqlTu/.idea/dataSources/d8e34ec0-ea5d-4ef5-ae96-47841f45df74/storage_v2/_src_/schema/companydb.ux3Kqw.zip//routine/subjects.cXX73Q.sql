create
  definer = root@localhost procedure subjects(IN S_Subject varchar(25), OUT total int)
BEGIN
SELECT id FROM student_info where Subject = 'Computers';
END;

