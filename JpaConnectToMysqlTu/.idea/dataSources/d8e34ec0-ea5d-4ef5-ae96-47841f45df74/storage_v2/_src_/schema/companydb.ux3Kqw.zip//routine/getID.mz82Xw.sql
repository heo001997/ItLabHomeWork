create
  definer = root@localhost procedure getID(IN S_Subject varchar(25), OUT total int)
BEGIN
SELECT id FROM student_info WHERE Subject = S_Subject;
END;

